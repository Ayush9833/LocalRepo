const mongoose = require("mongoose");

const issueSchema = new mongoose.Schema(
  {
    book: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Book",
      required: true
    },
    member: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Member",
      required: true
    },
    issueDate: {
      type: Date,
      default: Date.now
    },
    dueDate: {
      type: Date,
      required: true
    },
    returnDate: {
      type: Date,
      default: null
    },
    status: {
      type: String,
      enum: ["issued", "returned", "overdue"],
      default: "issued"
    },
    lateFee: {
      type: Number,
      default: 0,
      min: 0
    }
  },
  { timestamps: true }
);

issueSchema.index({ book: 1, status: 1 });
issueSchema.index({ member: 1, status: 1 });
issueSchema.index({ dueDate: 1, status: 1 });

module.exports = mongoose.model("Issue", issueSchema);