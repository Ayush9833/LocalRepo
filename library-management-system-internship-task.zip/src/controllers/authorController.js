const Author = require("../models/Author");
const { getPagination, buildPagination } = require("../utils/apiFeatures");
const { sendSuccess, sendError } = require("../utils/response");

exports.create = async (req, res, next) => {
  try {
    const author = await Author.create(req.body);
    return sendSuccess(res, 201, "Author created successfully", author);
  } catch (error) {
    next(error);
  }
};

exports.list = async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const filter = {};

    if (req.query.search) {
      filter.$text = { $search: req.query.search };
    }

    const [authors, total] = await Promise.all([
      Author.find(filter).sort({ name: 1 }).skip(skip).limit(limit),
      Author.countDocuments(filter)
    ]);

    return sendSuccess(
      res,
      200,
      "Authors fetched successfully",
      authors,
      buildPagination(page, limit, total)
    );
  } catch (error) {
    next(error);
  }
};

exports.getOne = async (req, res, next) => {
  try {
    const author = await Author.findById(req.params.id);
    if (!author) return sendError(res, 404, "Author not found");
    return sendSuccess(res, 200, "Author fetched successfully", author);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const author = await Author.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    if (!author) return sendError(res, 404, "Author not found");
    return sendSuccess(res, 200, "Author updated successfully", author);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const author = await Author.findByIdAndDelete(req.params.id);
    if (!author) return sendError(res, 404, "Author not found");
    return sendSuccess(res, 200, "Author deleted successfully");
  } catch (error) {
    next(error);
  }
};