const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Book title is required"],
      trim: true,
      minlength: 1,
      maxlength: 200
    },
    isbn: {
      type: String,
      required: [true, "ISBN is required"],
      unique: true,
      trim: true
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Author",
      required: [true, "Author is required"]
    },
    category: {
      type: String,
      trim: true,
      default: "General"
    },
    totalCopies: {
      type: Number,
      required: true,
      min: 1,
      default: 1
    },
    availableCopies: {
      type: Number,
      required: true,
      min: 0
    },
    publishedYear: {
      type: Number,
      min: 0,
      max: new Date().getFullYear()
    }
  },
  { timestamps: true }
);

bookSchema.index({ title: "text", isbn: "text", category: "text" });
bookSchema.index({ author: 1 });

bookSchema.pre("validate", function(next) {
  if (this.availableCopies > this.totalCopies) {
    this.invalidate("availableCopies", "Available copies cannot exceed total copies");
  }
  next();
});

module.exports = mongoose.model("Book", bookSchema);