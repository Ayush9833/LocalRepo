const express = require("express");
const controller = require("../controllers/issueController");

const router = express.Router();

router.post("/", controller.issueBook);
router.get("/", controller.list);
router.get("/:id", controller.getOne);
router.post("/:id/return", controller.returnBook);

module.exports = router;