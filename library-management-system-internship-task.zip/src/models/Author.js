const mongoose = require("mongoose");

const authorSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Author name is required"],
      trim: true,
      minlength: 2,
      maxlength: 100
    },
    bio: {
      type: String,
      trim: true,
      maxlength: 1000,
      default: ""
    }
  },
  { timestamps: true }
);

authorSchema.index({ name: "text" });

module.exports = mongoose.model("Author", authorSchema);