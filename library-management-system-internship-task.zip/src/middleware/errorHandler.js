module.exports = (err, req, res, next) => {
  console.error(err);

  if (err.name === "ValidationError") {
    return res.status(400).json({
      success: false,
      message: "Validation failed",
      errors: Object.values(err.errors).map((e) => e.message)
    });
  }

  if (err.name === "CastError") {
    return res.status(400).json({
      success: false,
      message: "Invalid ID format"
    });
  }

  if (err.code === 11000) {
    return res.status(409).json({
      success: false,
      message: "A record with this unique value already exists",
      fields: Object.keys(err.keyPattern || {})
    });
  }

  const status = err.statusCode || 500;

  res.status(status).json({
    success: false,
    message: err.message || "Internal server error"
  });
};