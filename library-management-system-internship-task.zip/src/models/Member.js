const mongoose = require("mongoose");

const memberSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Member name is required"],
      trim: true,
      minlength: 2,
      maxlength: 100
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true
    },
    phone: {
      type: String,
      trim: true,
      maxlength: 20
    },
    address: {
      type: String,
      trim: true,
      maxlength: 300
    },
    active: {
      type: Boolean,
      default: true
    }
  },
  { timestamps: true }
);

memberSchema.index({ name: "text", email: "text" });

module.exports = mongoose.model("Member", memberSchema);