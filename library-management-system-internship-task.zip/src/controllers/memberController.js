const Member = require("../models/Member");
const Issue = require("../models/Issue");
const { getPagination, buildPagination } = require("../utils/apiFeatures");
const { sendSuccess, sendError } = require("../utils/response");

exports.create = async (req, res, next) => {
  try {
    const member = await Member.create(req.body);
    return sendSuccess(res, 201, "Member created successfully", member);
  } catch (error) {
    next(error);
  }
};

exports.list = async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const filter = {};

    if (req.query.search) filter.$text = { $search: req.query.search };
    if (req.query.active !== undefined) filter.active = req.query.active === "true";

    const [members, total] = await Promise.all([
      Member.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
      Member.countDocuments(filter)
    ]);

    return sendSuccess(
      res,
      200,
      "Members fetched successfully",
      members,
      buildPagination(page, limit, total)
    );
  } catch (error) {
    next(error);
  }
};

exports.getOne = async (req, res, next) => {
  try {
    const member = await Member.findById(req.params.id);
    if (!member) return sendError(res, 404, "Member not found");
    return sendSuccess(res, 200, "Member fetched successfully", member);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const member = await Member.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    if (!member) return sendError(res, 404, "Member not found");
    return sendSuccess(res, 200, "Member updated successfully", member);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const activeIssue = await Issue.findOne({
      member: req.params.id,
      status: { $in: ["issued", "overdue"] }
    });

    if (activeIssue) {
      return sendError(res, 400, "Cannot delete a member with active issued books");
    }

    const member = await Member.findByIdAndDelete(req.params.id);
    if (!member) return sendError(res, 404, "Member not found");

    return sendSuccess(res, 200, "Member deleted successfully");
  } catch (error) {
    next(error);
  }
};