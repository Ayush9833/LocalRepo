const express = require("express");
const controller = require("../controllers/reportController");

const router = express.Router();

router.get("/dashboard", controller.dashboard);

module.exports = router;