# Library Management System API

Internship Task 4 submission — REST API backend built with Node.js, Express.js and MongoDB.

## Features

- CRUD for books, authors and members
- Issue and return books
- Book availability tracking
- Borrowing history
- Duplicate issue prevention
- Maximum 5 active books per member
- Search, filtering and pagination
- Overdue detection
- Automatic late-fee calculation
- Dashboard/library report
- Validation and meaningful HTTP responses
- Clean MVC-style project architecture
- Helmet, CORS and request logging

## Tech Stack

- Node.js 20+
- Express.js
- MongoDB
- Mongoose
- REST API
- Postman for testing

## Project Structure

```text
library-management-system/
├── src/
│   ├── config/
│   │   └── db.js
│   ├── controllers/
│   │   ├── authorController.js
│   │   ├── bookController.js
│   │   ├── issueController.js
│   │   ├── memberController.js
│   │   └── reportController.js
│   ├── middleware/
│   │   ├── errorHandler.js
│   │   └── notFound.js
│   ├── models/
│   │   ├── Author.js
│   │   ├── Book.js
│   │   ├── Issue.js
│   │   └── Member.js
│   ├── routes/
│   │   ├── authorRoutes.js
│   │   ├── bookRoutes.js
│   │   ├── issueRoutes.js
│   │   ├── memberRoutes.js
│   │   └── reportRoutes.js
│   ├── utils/
│   │   ├── apiFeatures.js
│   │   └── response.js
│   └── app.js
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Setup

### 1. Install Node.js

Use Node.js 20 or newer.

### 2. Install dependencies

```bash
npm install
```

### 3. Configure MongoDB

Create a local MongoDB database or use MongoDB Atlas.

Copy `.env.example` to `.env` and update:

```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/library_management
DEFAULT_LOAN_DAYS=14
DAILY_LATE_FEE=5
NODE_ENV=development
```

### 4. Start server

Development:

```bash
npm run dev
```

Production:

```bash
npm start
```

Server:

```text
http://localhost:5000
```

Health check:

```text
GET http://localhost:5000/api/health
```

## API Endpoints

### Authors

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/authors` | Create author |
| GET | `/api/authors` | List/search authors |
| GET | `/api/authors/:id` | Get author |
| PUT | `/api/authors/:id` | Update author |
| DELETE | `/api/authors/:id` | Delete author |

Search and pagination:

```text
GET /api/authors?search=martin&page=1&limit=10
```

### Books

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/books` | Add book |
| GET | `/api/books` | List/search/filter books |
| GET | `/api/books/:id` | Get book |
| PUT | `/api/books/:id` | Update book |
| DELETE | `/api/books/:id` | Delete book |

Examples:

```text
GET /api/books?search=java&page=1&limit=10
GET /api/books?category=Programming
GET /api/books?available=true
GET /api/books?author=AUTHOR_ID
```

Create book:

```json
{
  "title": "Clean Code",
  "isbn": "9780132350884",
  "author": "AUTHOR_ID",
  "category": "Programming",
  "totalCopies": 5,
  "publishedYear": 2008
}
```

### Members

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/members` | Create member |
| GET | `/api/members` | List/search/filter members |
| GET | `/api/members/:id` | Get member |
| PUT | `/api/members/:id` | Update member |
| DELETE | `/api/members/:id` | Delete member |

Create member:

```json
{
  "name": "Rahul Sharma",
  "email": "rahul@example.com",
  "phone": "9876543210",
  "address": "Delhi"
}
```

### Issue / Return

Issue a book:

```text
POST /api/issues
```

Body:

```json
{
  "bookId": "BOOK_ID",
  "memberId": "MEMBER_ID"
}
```

Optional custom due date:

```json
{
  "bookId": "BOOK_ID",
  "memberId": "MEMBER_ID",
  "dueDate": "2026-09-01T00:00:00.000Z"
}
```

Return a book:

```text
POST /api/issues/ISSUE_ID/return
```

Borrowing history:

```text
GET /api/issues
GET /api/issues?status=overdue
GET /api/issues?status=returned
GET /api/issues?memberId=MEMBER_ID
GET /api/issues?bookId=BOOK_ID
GET /api/issues?page=1&limit=10
```

### Reports

```text
GET /api/reports/dashboard
```

The dashboard reports:

- Unique book titles
- Total copies
- Available copies
- Total members
- Active members
- Total issues
- Active issues
- Overdue issues
- Returned issues
- Total late fees

## Business Rules

1. A book cannot be issued if no copy is available.
2. A member cannot issue the same book twice at the same time.
3. A member can have a maximum of 5 active books.
4. Inactive members cannot borrow books.
5. Returning a book increases available copies.
6. Overdue issues are automatically marked as overdue when issue history/report is requested.
7. Late fee defaults to ₹5 per overdue day.
8. Default borrowing period is 14 days.
9. A book cannot be deleted while an active copy is issued.
10. A member cannot be deleted while they have active issues.

## Suggested Postman Test Flow

1. Create an author.
2. Copy the returned author `_id`.
3. Create a book using that author ID.
4. Create a member.
5. Issue the book.
6. Check `GET /api/books` and verify `availableCopies` decreased.
7. Try issuing the same book to the same member again — it should fail.
8. Return the book.
9. Verify `availableCopies` increased.
10. Open the dashboard report.

## Example Success Response

```json
{
  "success": true,
  "message": "Book created successfully",
  "data": {}
}
```

## Example Error Response

```json
{
  "success": false,
  "message": "Book is currently unavailable"
}
```

## Internship Submission Notes

Before submitting:

- Add your own GitHub repository URL to your internship submission.
- Add screenshots of successful Postman API tests.
- Do not upload `.env`.
- Mention MongoDB Atlas/local MongoDB in the setup instructions.
- Replace placeholder author/member/book IDs in the Postman requests with IDs generated by your database.

## Future Improvements

- JWT authentication and role-based access
- Admin dashboard frontend
- Email reminders for overdue books
- Docker deployment
- Automated tests with Jest/Supertest
- Rate limiting
