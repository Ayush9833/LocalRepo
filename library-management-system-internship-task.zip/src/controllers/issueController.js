const Book = require("../models/Book");
const Member = require("../models/Member");
const Issue = require("../models/Issue");
const { getPagination, buildPagination } = require("../utils/apiFeatures");
const { sendSuccess, sendError } = require("../utils/response");

const loanDays = () => Number(process.env.DEFAULT_LOAN_DAYS || 14);
const dailyFee = () => Number(process.env.DAILY_LATE_FEE || 5);

function calculateOverdueDays(dueDate, returnDate = new Date()) {
  const diff = new Date(returnDate).getTime() - new Date(dueDate).getTime();
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

exports.issueBook = async (req, res, next) => {
  try {
    const { bookId, memberId, dueDate } = req.body;

    if (!bookId || !memberId) {
      return sendError(res, 400, "bookId and memberId are required");
    }

    const [book, member] = await Promise.all([
      Book.findById(bookId),
      Member.findById(memberId)
    ]);

    if (!book) return sendError(res, 404, "Book not found");
    if (!member) return sendError(res, 404, "Member not found");
    if (!member.active) return sendError(res, 400, "Member is inactive");
    if (book.availableCopies < 1) {
      return sendError(res, 409, "Book is currently unavailable");
    }

    const duplicate = await Issue.findOne({
      book: bookId,
      member: memberId,
      status: { $in: ["issued", "overdue"] }
    });

    if (duplicate) {
      return sendError(res, 409, "This member already has this book issued");
    }

    const activeBorrow = await Issue.countDocuments({
      member: memberId,
      status: { $in: ["issued", "overdue"] }
    });

    const maxBooks = 5;
    if (activeBorrow >= maxBooks) {
      return sendError(res, 400, `A member cannot have more than ${maxBooks} active books`);
    }

    const issueDate = new Date();
    const calculatedDueDate = dueDate
      ? new Date(dueDate)
      : new Date(issueDate.getTime() + loanDays() * 24 * 60 * 60 * 1000);

    if (Number.isNaN(calculatedDueDate.getTime()) || calculatedDueDate <= issueDate) {
      return sendError(res, 400, "dueDate must be a valid future date");
    }

    const issue = await Issue.create({
      book: bookId,
      member: memberId,
      issueDate,
      dueDate: calculatedDueDate
    });

    book.availableCopies -= 1;
    await book.save();

    const populated = await issue.populate([
      { path: "book", select: "title isbn category" },
      { path: "member", select: "name email" }
    ]);

    return sendSuccess(res, 201, "Book issued successfully", populated);
  } catch (error) {
    next(error);
  }
};

exports.returnBook = async (req, res, next) => {
  try {
    const issue = await Issue.findById(req.params.id);

    if (!issue) return sendError(res, 404, "Issue record not found");
    if (issue.status === "returned") {
      return sendError(res, 400, "This book has already been returned");
    }

    const returnDate = new Date();
    const overdueDays = calculateOverdueDays(issue.dueDate, returnDate);
    const lateFee = overdueDays * dailyFee();

    issue.returnDate = returnDate;
    issue.status = "returned";
    issue.lateFee = lateFee;
    await issue.save();

    await Book.findByIdAndUpdate(issue.book, {
      $inc: { availableCopies: 1 }
    });

    const populated = await issue.populate([
      { path: "book", select: "title isbn category" },
      { path: "member", select: "name email" }
    ]);

    return sendSuccess(res, 200, "Book returned successfully", {
      issue: populated,
      overdueDays,
      lateFee
    });
  } catch (error) {
    next(error);
  }
};

exports.list = async (req, res, next) => {
  try {
    await Issue.updateMany(
      {
        status: "issued",
        dueDate: { $lt: new Date() }
      },
      { $set: { status: "overdue" } }
    );

    const { page, limit, skip } = getPagination(req.query);
    const filter = {};

    if (req.query.status) filter.status = req.query.status;
    if (req.query.memberId) filter.member = req.query.memberId;
    if (req.query.bookId) filter.book = req.query.bookId;

    const [issues, total] = await Promise.all([
      Issue.find(filter)
        .populate("book", "title isbn")
        .populate("member", "name email")
        .sort({ issueDate: -1 })
        .skip(skip)
        .limit(limit),
      Issue.countDocuments(filter)
    ]);

    return sendSuccess(
      res,
      200,
      "Borrowing history fetched successfully",
      issues,
      buildPagination(page, limit, total)
    );
  } catch (error) {
    next(error);
  }
};

exports.getOne = async (req, res, next) => {
  try {
    const issue = await Issue.findById(req.params.id)
      .populate("book", "title isbn category")
      .populate("member", "name email phone");

    if (!issue) return sendError(res, 404, "Issue record not found");

    let overdueDays = 0;
    let currentLateFee = issue.lateFee;

    if (issue.status !== "returned") {
      overdueDays = calculateOverdueDays(issue.dueDate);
      currentLateFee = overdueDays * dailyFee();
    }

    return sendSuccess(res, 200, "Issue record fetched successfully", {
      ...issue.toObject(),
      overdueDays,
      currentLateFee
    });
  } catch (error) {
    next(error);
  }
};