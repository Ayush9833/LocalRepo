const Book = require("../models/Book");
const Member = require("../models/Member");
const Issue = require("../models/Issue");
const { sendSuccess } = require("../utils/response");

exports.dashboard = async (req, res, next) => {
  try {
    const now = new Date();

    await Issue.updateMany(
      { status: "issued", dueDate: { $lt: now } },
      { $set: { status: "overdue" } }
    );

    const [
      totalBooks,
      totalCopies,
      availableCopies,
      totalMembers,
      activeMembers,
      totalIssues,
      activeIssues,
      overdueIssues,
      returnedIssues,
      fees
    ] = await Promise.all([
      Book.countDocuments(),
      Book.aggregate([{ $group: { _id: null, total: { $sum: "$totalCopies" } } }]),
      Book.aggregate([{ $group: { _id: null, total: { $sum: "$availableCopies" } } }]),
      Member.countDocuments(),
      Member.countDocuments({ active: true }),
      Issue.countDocuments(),
      Issue.countDocuments({ status: { $in: ["issued", "overdue"] } }),
      Issue.countDocuments({ status: "overdue" }),
      Issue.countDocuments({ status: "returned" }),
      Issue.aggregate([{ $group: { _id: null, total: { $sum: "$lateFee" } } }])
    ]);

    return sendSuccess(res, 200, "Library report generated successfully", {
      books: {
        uniqueTitles: totalBooks,
        totalCopies: totalCopies[0]?.total || 0,
        availableCopies: availableCopies[0]?.total || 0
      },
      members: {
        total: totalMembers,
        active: activeMembers
      },
      borrowing: {
        totalIssues,
        activeIssues,
        overdueIssues,
        returnedIssues
      },
      totalLateFeesCollected: fees[0]?.total || 0
    });
  } catch (error) {
    next(error);
  }
};