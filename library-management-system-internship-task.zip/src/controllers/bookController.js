const Book = require("../models/Book");
const Issue = require("../models/Issue");
const { getPagination, buildPagination } = require("../utils/apiFeatures");
const { sendSuccess, sendError } = require("../utils/response");

exports.create = async (req, res, next) => {
  try {
    const { totalCopies, availableCopies } = req.body;

    const book = await Book.create({
      ...req.body,
      totalCopies: totalCopies ?? 1,
      availableCopies: availableCopies ?? totalCopies ?? 1
    });

    const populated = await book.populate("author", "name bio");
    return sendSuccess(res, 201, "Book created successfully", populated);
  } catch (error) {
    next(error);
  }
};

exports.list = async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const filter = {};

    if (req.query.search) {
      filter.$text = { $search: req.query.search };
    }

    if (req.query.category) {
      filter.category = new RegExp(`^${req.query.category}$`, "i");
    }

    if (req.query.author) {
      filter.author = req.query.author;
    }

    if (req.query.available === "true") filter.availableCopies = { $gt: 0 };
    if (req.query.available === "false") filter.availableCopies = 0;

    const [books, total] = await Promise.all([
      Book.find(filter)
        .populate("author", "name")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Book.countDocuments(filter)
    ]);

    return sendSuccess(
      res,
      200,
      "Books fetched successfully",
      books,
      buildPagination(page, limit, total)
    );
  } catch (error) {
    next(error);
  }
};

exports.getOne = async (req, res, next) => {
  try {
    const book = await Book.findById(req.params.id).populate("author", "name bio");
    if (!book) return sendError(res, 404, "Book not found");
    return sendSuccess(res, 200, "Book fetched successfully", book);
  } catch (error) {
    next(error);
  }
};

exports.update = async (req, res, next) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return sendError(res, 404, "Book not found");

    const activeIssues = await Issue.countDocuments({
      book: book._id,
      status: { $in: ["issued", "overdue"] }
    });

    if (req.body.totalCopies !== undefined && req.body.totalCopies < activeIssues) {
      return sendError(
        res,
        400,
        `Total copies cannot be less than currently issued copies (${activeIssues})`
      );
    }

    Object.assign(book, req.body);

    if (req.body.totalCopies !== undefined && req.body.availableCopies === undefined) {
      book.availableCopies = req.body.totalCopies - activeIssues;
    }

    await book.save();

    const populated = await book.populate("author", "name bio");
    return sendSuccess(res, 200, "Book updated successfully", populated);
  } catch (error) {
    next(error);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const activeIssue = await Issue.findOne({
      book: req.params.id,
      status: { $in: ["issued", "overdue"] }
    });

    if (activeIssue) {
      return sendError(res, 400, "Cannot delete a book while it is issued");
    }

    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) return sendError(res, 404, "Book not found");

    return sendSuccess(res, 200, "Book deleted successfully");
  } catch (error) {
    next(error);
  }
};